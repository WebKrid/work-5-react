import React from "react";
import { useDispatch, useSelector } from "react-redux";
function App() {
  const [const1, setCount1] = React.useState(0);
  const [count2, setCount2] = React.useState(0);
}

return (
  <div className="App">
   <h5> Счетчик 1:</h5>
   <div className="conter">
    <button onClick={() => setCount (count2 + 1)}>+</button>
     <Count id={2} value={count2} />
     <InFive value={count2} />
   </div>
  </div>
)


export default App;